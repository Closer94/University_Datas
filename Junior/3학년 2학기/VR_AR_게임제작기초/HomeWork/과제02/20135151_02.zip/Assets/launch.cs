﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class launch : MonoBehaviour
{
    float power = 100.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.UpArrow)) {
            this.transform.Translate(Vector3.forward * 5.0f * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.DownArrow)) {
            this.transform.Translate(Vector3.back * 5.0f * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.LeftArrow)) {
            this.transform.Translate(Vector3.left * 5.0f * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.RightArrow)) {
            this.transform.Translate(Vector3.right * 5.0f * Time.deltaTime);
        }
        
    }

    void OnCollisionEnter(Collision coll) {
        coll.gameObject.GetComponent<Rigidbody>().AddForce(new Vector3(0, 1, 1) * power);
    }
}
