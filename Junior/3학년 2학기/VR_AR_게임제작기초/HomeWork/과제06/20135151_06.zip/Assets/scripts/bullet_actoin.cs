﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class bullet_actoin : MonoBehaviour
{
    public AudioClip collision_sound;
    public Transform explosion_effect;
    public static bool isFinish = false;

    float elapsed_time = 0.0f;
    float destroy_time = 5.0f;


    void Update() {
     
        elapsed_time += Time.deltaTime; //포탄 발사후 소요시간 체크

        if (elapsed_time >= destroy_time)
        {
            Debug.Log(elapsed_time);
            Destroy(this.gameObject);
        }

    }

    void OnTriggerEnter(Collider other) {


        Instantiate(explosion_effect, this.transform.position, this.transform.rotation);
        AudioSource.PlayClipAtPoint(collision_sound, this.transform.position);
        Destroy(this.gameObject);

        if (other.gameObject.tag == "Obstacle")
        {
            Destroy(other.gameObject);
        }
        else if (other.gameObject.tag == "Enemy")
        {
            score_record.win++;
            if (score_record.win > 5) {
                isFinish = true;
                SceneManager.LoadScene("win_screen");
            }
        }
        else if (other.gameObject.tag == "Tank") {
            score_record.lose++;
            if (score_record.lose > 5) {
                isFinish = true;
                SceneManager.LoadScene("lose_screen");
            }
        }
        
    }
}
