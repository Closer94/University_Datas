﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class enemy_move : MonoBehaviour
{
    public float rot_angle = 15.0f;
    public UnityEngine.AI.NavMeshAgent agent;
    public GameObject target;
 

    // Update is called once per frame
    void Update()
    {
        agent.speed += (agent.speed * 0.01f) * Time.deltaTime;
        Debug.Log(agent.speed);
        MoveToTarget();

    }

    void MoveToTarget() {
        agent.SetDestination(target.transform.position);
        
    }

    void OnGUI() {
        GUI.Label(new Rect(10, 50, 120, 120), "Enemy Speed: " + agent.speed);
    }
}
