﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class score_record : MonoBehaviour
{
    public static int win = 0;
    public static int lose = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    void Update() {
        if (bullet_actoin.isFinish)
        {
            if (Input.anyKeyDown)
            {
                score_record.win = 0;
                score_record.lose = 0;
                SceneManager.LoadScene("main_game");
                bullet_actoin.isFinish = false;
            }
        }
    }

    // Update is called once per frame
    void OnGUI()
    {
        GUI.Label(new Rect(10, 10, 120, 120), "Win: " + win);
        GUI.Label(new Rect(10, 30, 120, 120), "Lose: " + lose);
    }
}
