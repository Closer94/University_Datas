﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawn : MonoBehaviour
{
    public GameObject pf_wall;
    public float interval;

    // Start is called before the first frame update
    IEnumerator Start()
    {
        interval = Random.Range(1.0f, 2.0f);
        while (true)
        {
            Instantiate(pf_wall, new Vector3(13, Random.Range(-3.0f, 4.0f), 0), transform.rotation);
            yield return new WaitForSeconds(interval);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    

}
