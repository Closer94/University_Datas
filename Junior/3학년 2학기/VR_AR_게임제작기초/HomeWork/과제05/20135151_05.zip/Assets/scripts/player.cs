﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class player : MonoBehaviour
{
    public float jump_power;
    private float survive = 0.0f;
    // Start is called before the first frame update
    void Start()
    {
   
    }

    // Update is called once per frame
    void Update()
    {
        survive += Time.deltaTime; 
        if (Input.GetButton("Jump"))
        {
            jump_power = Random.Range(4.0f, 9.0f);
            GetComponent<Rigidbody>().velocity = new Vector3(0, jump_power, 0);
        }
    }
    void OnCollisionEnter(Collision other)
    {
        SceneManager.LoadScene("SampleScene");
    }

    void OnGUI()
    {
        GUI.Label(new Rect(50, 40, 64, 64), "[점프력] " + jump_power.ToString());
        GUI.Label(new Rect(50, 100, 64, 64), "[생존시간]" + survive.ToString());
    }
}
