﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class goal_ctrl : MonoBehaviour
{
    private bool is_collided = false;
    float xRnd, yRnd;
    private int cnt = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
     
    }

    void OnCollisionStay(Collision other) {
        this.is_collided = true;
        cnt++;
        other.transform.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeAll;
        
        if (is_collided == true) //goal에 유니토가 닿았을때
        {
            other.transform.position = new Vector3(0, 0, 0); //유니토 초기값으로 변경
            other.transform.rotation = Quaternion.Euler(0, 90.0f, 0);
            other.transform.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None; //유니토 움직임 제약을 해제
            //x,y 축 random값 지정
            xRnd = Random.Range(5.0f, 10.0f);
            yRnd = Random.Range(-3.0f, 1.0f);
            transform.position = new Vector3(xRnd, yRnd); //goal의 위치 변경
        }
        
    }

    void OnGUI()
    {
        if (is_collided)
        {
            GUI.Label(new Rect(Screen.width / 2 - 30, 80, 100, 20), (cnt).ToString() + "th Success!!!" );

        }
        
        
    }
}
