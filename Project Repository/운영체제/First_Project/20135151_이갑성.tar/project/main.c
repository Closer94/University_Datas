#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "sha1.h"
#include <time.h>

#define MAX 1024

int main()
{
	int i, n;
        //FILE *fp;
	int fp, fp1, fp2;
        char buffer[MAX];
	SHA1Context sha1;
        static unsigned char hash[20] = {0};
	
	DIR *dp;
	struct dirent *dirp;
	char* txtName[4];
	int index = 0;
	static unsigned char hashData[4][100] = {0};
	int dataIndex = 0;
	int result1, result2;
	int flag = 1;
	struct stat st;
	
	char buf1[1];
	char buf2[1];	
	int cnt1, cnt2;
	char enter[20];

	printf("방문하고자 하는 디렉토리를 입력하세요 >> ");
	scanf("%s", enter);

        chdir(enter); //data디렉토리로 변경

	if((dp = opendir(".")) == NULL){ //data 디렉토리에 방문
                perror("opendir failed");
                exit(1);
        }

 	while(dirp = readdir(dp)){ //data디렉토리 안의 파일 목록들 배열에 넣어주기
                //printf("%s ", dirp->d_name);
		txtName[index] = dirp->d_name;
		index++;
	} 
	//txtName[0] = diamond.txt, txtName[1] = ruby.txt, txtName[2] = stone.txt, txtName[3] = .
	//txtName[4] = .., txtName[5] = emerald.txt 
	//5번째에 있는 emerald.txt를 3번째로 옮겨준다.
	txtName[3] = txtName[5];
	
	printf("=============== %s 디렉토리에 있는 파일 출력 ============ \n", enter);
	for(i = 0; i < 4; i++) //파일에 출력
	{
		printf("%d번째 파일: %s \n", i, txtName[i]);
	}
	
	printf("=============== %s 디렉토리에 있는 파일 해시값 출력 ============ \n", enter);
	for(int j = 0; j < 4; j++)
	{
		if((fp = open(txtName[j], O_RDONLY, 0644)) == -1)
		{
			perror("open failed");
			exit(1);
		}
		SHA1Reset(&sha1);
		while((n = read(fp, buffer, MAX)))
		{
			SHA1Input(&sha1, buffer, n);
		}
		SHA1Result(&sha1, hash);

		printf(">> %s의 SHA1 hash: ", txtName[j]);
		for(i = 0; i < 20; i++)
		{
			printf("%02x", hash[i]);			
		}

		//헤쉬값 복사
		for(i = 0; i < 20; i++)
		{
			hashData[dataIndex][i] = hash[i];
		}
		dataIndex++; //헤쉬값을 복사하는 배열의 인덱스 증가
		printf("\n");
		
		close(fp); //열었던 txtName[i]를 닫아준다.
	}

	printf("====================== 해시값 비교 =====================\n");
	for(i = 0; i < 4; i++)
	{
		for(int k = i+1; k < 4; k++)
		{
			flag = 1;
			for(int j = 0; j < 20; j++)
			{
				if(hashData[i][j] != hashData[k][j]){
					flag = 0;
					break;
				} 				
			}
			if(flag == 1)
			{
				result1 = i;
				result2 = k;	
			}
		}
	}
	
	printf("%s 와 %s의 파일이 같습니다. \n", txtName[result1], txtName[result2]);
	printf("===================== 파일 정보 출력 ======================\n");
	printf(">> %s 파일 정보 출력 \n", txtName[result1]);
	if(stat(txtName[result1], &st) == -1)
	{
		perror("stat failed");
		exit(1);
	}

	printf("%ld byte, user-id %d, group-id %d, modify time %s", st.st_size, st.st_uid,
			st.st_gid, ctime(&st.st_mtime));
	
	printf(">> %s 파일 정보 출력 \n", txtName[result2]);
	if(stat(txtName[result1], &st) == -1)
	{
	        perror("stat failed");
	        exit(1);
	}

	printf("%ld byte, user-id %d, group-id %d, modify time %s", st.st_size, st.st_uid,
	                 st.st_gid, ctime(&st.st_mtime));
	
	printf("============================ lseek()함수 구현 =========================\n");
	//해시값이 다른 파일들은 해시값이 같은 파일들과 비교했을 때 어느부분이 다른지 출력
	if((fp1 = open(txtName[0], O_RDONLY, 0644)) == -1){ //diamond.txt 파일을 열어준다.
		perror("open failed");
		exit(1);
	}

	if((fp2 = open(txtName[result1], O_RDONLY, 0644)) == -1){ //해시값이 같은 파일중 stone.txt 파일을 열어준다.
		perror("open failed");
		exit(1);
	}

	lseek(fp1, 1, SEEK_CUR); //fp1 1칸 이동
	lseek(fp2, 1, SEEK_CUR); //fp2 1칸 이동

	do
	{
		read(fp1, buf1, 1);
		read(fp2, buf2, 1);
	
		if(buf1[0] != buf2[0])
		{
			break;
		}

	}while(!(buf1[0] == '\0'));

	printf("%s의 %c 가 다르다.(기준이 되는 %s은 %c 이다.) \n",txtName[0], buf1[0],txtName[3], buf2[0]);
	close(fp1); //fp1 닫아줌(diamond.txt 닫아줌)
	
	if((fp1 = open(txtName[1], O_RDONLY, 0644)) == -1){ //diamond.txt 파일을 열어준다.
                perror("open failed");
                exit(1);
        }
        lseek(fp1, 1, SEEK_SET); //fp1 1칸 이동
        lseek(fp2, 1, SEEK_SET); //fp2 1칸 이동

        do
        {
                read(fp1, buf1, 1);
                read(fp2, buf2, 1);
                if(buf1[0] != buf2[0])
                {
                        break;
                }
        }while(!(buf1[0] == '\0'));

        printf("%s의 %c 가 다르다.(기준이 되는 %s은 %c 이다.) \n",txtName[1], buf1[0],txtName[3], buf2[0]);

	close(fp1);
	close(fp2); //fp2 닫아줌
	


	closedir(dp); //열었던 data 디렉토리를 닫아준다.
        exit(0); //끝낸다.
}

