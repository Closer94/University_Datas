package jsp.db;

public class EducationDB {

}
