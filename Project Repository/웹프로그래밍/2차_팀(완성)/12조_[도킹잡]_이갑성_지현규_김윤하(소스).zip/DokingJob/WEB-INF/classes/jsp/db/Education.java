package jsp.db;

public class Education {
    private Integer eduId;

    // ��������(����, ���, ����, ��û, ����, ���, ����)
    private String eduRegion;

    // ����, ���
    private String eduType;

    // ���� �о�
    private String eduInterest;

    // ������
    private String eduTitle;

    // ������
    private String eduFee;

    // �п���,�����
    private String eduInstitute;

    // �ƷñⰣ
    private String eduTerm;

    // ����URl
    private String eduUrl;

    public Integer getEduId() {
        return eduId;
    }

    public void setEduId(Integer eduId) {
        this.eduId = eduId;
    }

    public String getEduRegion() {
        return eduRegion;
    }

    public void setEduRegion(String eduRegion) {
        this.eduRegion = eduRegion;
    }

    public String getEduType() {
        return eduType;
    }

    public void setEduType(String eduType) {
        this.eduType = eduType;
    }

    public String getEduInterest() {
        return eduInterest;
    }

    public void setEduInterest(String eduInterest) {
        this.eduInterest = eduInterest;
    }

    public String getEduTitle() {
        return eduTitle;
    }

    public void setEduTitle(String eduTitle) {
        this.eduTitle = eduTitle;
    }

    public String getEduFee() {
        return eduFee;
    }

    public void setEduFee(String eduFee) {
        this.eduFee = eduFee;
    }

    public String getEduInstitute() {
        return eduInstitute;
    }

    public void setEduInstitute(String eduInstitute) {
        this.eduInstitute = eduInstitute;
    }

    public String getEduTerm() {
        return eduTerm;
    }

    public void setEduTerm(String eduTerm) {
        this.eduTerm = eduTerm;
    }

    public String getEduUrl() {
        return eduUrl;
    }

    public void setEduUrl(String eduUrl) {
        this.eduUrl = eduUrl;
    }
}
